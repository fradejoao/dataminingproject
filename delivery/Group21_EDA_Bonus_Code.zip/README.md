# Group 21 — optional EDA bonus code

Members: João Frade (20260557), Alfredo Soudo (20260591), Maria Coutinho (20260657).

The separately submitted Group21_EDA_Code.ipynb contains the complete multidimensional anomaly-detection bonus. Its opening section identifies both bonuses and their locations. This archive supplies the external Python implementation of the second bonus, the interactive EDA dashboard.

## Reproduce the dashboard

1. Extract this whole archive into a project directory, preserving its structure.
2. Put the separately submitted `Group21_EDA_Code.ipynb` inside a `notebooks/` subdirectory.
3. Put the original course dataset `acdc_dataset.csv` in `data/raw/`.
4. From the project directory, install dependencies:

```bash
python -m pip install -r requirements-dashboard.txt
python -m jupyterlab
```

Open `notebooks/Group21_EDA_Code.ipynb` and run all cells with the kernel working directory set to `notebooks/`. The final dashboard code cell creates `data/processed/acdc_dashboard.csv`. The raw data are supplied by the course and are not included in this code archive.

Then, from the project directory:

```bash
python -m streamlit run dashboard/app.py
```

Open the local address printed by Streamlit, normally http://localhost:8501.

## Features and scope

Filter by current plan, individual/team account and review cohort. Inspect revenue/utilization distributions, service percentages and plan summaries. Find member IDs, inspect reported services and download selected records. Indicators show the observed sample sizes. All 15,450 prepared members remain available. Unscored anomaly flags remain missing; the model is not refitted after filtering. This is a local application.

The app reads the notebook export and does not repeat or change cleaning decisions. The notebook documents missing data, different observation windows, conditional imputations, unresolved recency/dates and the exploratory nature of anomaly flags. The screenshot in `preview/` illustrates the application, not a separate dataset or model.

## Verification

The notebook has 76 executed code cells with outputs. Dashboard interaction/data tests passed in two environments. After generating the snapshot, the included tests can be run with:

```bash
python -m pip install pytest
python -m pytest tests/test_dashboard.py -q
```

Source repository: https://github.com/fradejoao/dataminingproject
